defmodule EventManagerWeb.PageController do
  @moduledoc """
  Home page controller for the application.
  """
  use EventManagerWeb, :controller

  def home(conn, _params) do
    upcoming_events = EventManager.Core.list_events(
      status: :published,
      upcoming_only: true,
      order_by: {:date, :asc}
    ) |> Enum.take(6)

    stats = EventManager.Services.get_system_stats()

    render(conn, :home, events: upcoming_events, stats: stats)
  end
end