defmodule EventManagerWeb.EventChatLive do
  @moduledoc "LiveView for event chat with Q&A."
  use EventManagerWeb, :live_view
  

  @impl true
  def mount(%{"id" => event_id}, _session, socket) do
    if connected?(socket), do: Phoenix.PubSub.subscribe(EventManager.PubSub, "event_chat:#{event_id}")

    {:ok, assign(socket,
      event: EventManager.Core.get_event!(event_id),
      messages: EventManager.Services.list_event_chat_messages(event_id, limit: 100),
      message_input: "",
      is_question: false
    )}
  end

  @impl true
  def handle_event("send_message", %{"message" => msg}, socket) do
    if String.trim(msg) != "" do
      EventManager.Services.create_chat_message(%{
        event_id: socket.assigns.event.id,
        user_id: socket.assigns.current_user.id,
        message: msg,
        is_question: socket.assigns.is_question
      })
    end
    {:noreply, assign(socket, message_input: "", is_question: false)}
  end

  @impl true
  def handle_event("toggle_question", _params, socket),
    do: {:noreply, update(socket, :is_question, &(!&1))}

  @impl true
  def handle_event("mark_answered", %{"message_id" => msg_id}, socket) do
    if socket.assigns.current_user.role in [:admin, :speaker] do
      EventManager.Services.mark_question_answered(msg_id)
    end
    {:noreply, socket}
  end

  @impl true
  def handle_info(%{event: "new_message", payload: msg}, socket),
    do: {:noreply, update(socket, :messages, &(&1 ++ [msg]))}

  @impl true
  def handle_info(%{event: "question_answered", payload: %{message_id: msg_id}}, socket) do
    messages = Enum.map(socket.assigns.messages, fn m ->
      if m.id == msg_id, do: %{m | is_answered: true}, else: m
    end)
    {:noreply, assign(socket, messages: messages)}
  end
end