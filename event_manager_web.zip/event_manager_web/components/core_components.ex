defmodule EventManagerWeb.CoreComponents do
  @moduledoc """
  Core UI components for the application.
  """
  use Phoenix.Component

  use Gettext, backend: EventManagerWeb.Gettext

  @doc "Renders a flash message"
  attr :kind, :atom, values: [:info, :error, :warning, :success], default: :info
  attr :flash, :any, default: nil
  attr :title, :string, default: nil

  def flash(%{kind: kind, flash: flash} = assigns) do
    assigns = assign(assigns, :msg, flash[kind])

    if assigns.msg do
      ~H"""
      <div class={[
        "px-4 py-3 rounded-lg mb-4",
        kind_classes(@kind)
      ]} role="alert">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <%= render_icon(@kind) %>
          </div>
          <div class="ml-3">
            <p class="text-sm font-medium"><%= @msg %></p>
          </div>
        </div>
      </div>
      """
    else
      ~H""
    end
  end

  defp kind_classes(:info), do: "bg-blue-100 text-blue-800"
  defp kind_classes(:success), do: "bg-green-100 text-green-800"
  defp kind_classes(:warning), do: "bg-yellow-100 text-yellow-800"
  defp kind_classes(:error), do: "bg-red-100 text-red-800"

  @doc "Renders a button"
  attr :type, :string, default: "button"
  attr :class, :string, default: ""
  attr :variant, :atom, values: [:primary, :secondary, :danger, :success], default: :primary
  attr :rest, :global, include: ~w(disabled form name value)

  slot :inner_block, required: true

  def button(assigns) do
    ~H"""
    <button
      type={@type}
      class={[
        "px-4 py-2 rounded-lg font-medium transition-colors",
        "focus:outline-none focus:ring-2 focus:ring-offset-2",
        variant_classes(@variant),
        @class
      ]}
      {@rest}
    >
      <%= render_slot(@inner_block) %>
    </button>
    """
  end

  defp variant_classes(:primary), do: "bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500"
  defp variant_classes(:secondary), do: "bg-gray-200 text-gray-800 hover:bg-gray-300 focus:ring-gray-500"
  defp variant_classes(:danger), do: "bg-red-600 text-white hover:bg-red-700 focus:ring-red-500"
  defp variant_classes(:success), do: "bg-green-600 text-white hover:bg-green-700 focus:ring-green-500"

  @doc "Renders a card component"
  attr :class, :string, default: ""
  slot :header
  slot :inner_block, required: true
  slot :footer

  def card(assigns) do
    ~H"""
    <div class={["bg-white rounded-lg shadow-md overflow-hidden", @class]}>
      <%= if @header != [] do %>
        <div class="px-6 py-4 border-b border-gray-200">
          <%= render_slot(@header) %>
        </div>
      <% end %>
      <div class="px-6 py-4">
        <%= render_slot(@inner_block) %>
      </div>
      <%= if @footer != [] do %>
        <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
          <%= render_slot(@footer) %>
        </div>
      <% end %>
    </div>
    """
  end

  @doc "Renders a badge"
  attr :text, :string, required: true
  attr :variant, :atom, values: [:default, :success, :warning, :danger, :info], default: :default

  def badge(assigns) do
    ~H"""
    <span class={[
      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
      badge_variant_classes(@variant)
    ]}>
      <%= @text %>
    </span>
    """
  end

  defp badge_variant_classes(:default), do: "bg-gray-100 text-gray-800"
  defp badge_variant_classes(:success), do: "bg-green-100 text-green-800"
  defp badge_variant_classes(:warning), do: "bg-yellow-100 text-yellow-800"
  defp badge_variant_classes(:danger), do: "bg-red-100 text-red-800"
  defp badge_variant_classes(:info), do: "bg-blue-100 text-blue-800"

  @doc "Renders an input field"
  attr :name, :string, required: true
  attr :label, :string, default: nil
  attr :type, :string, default: "text"
  attr :value, :any, default: nil
  attr :errors, :list, default: []
  attr :required, :boolean, default: false
  attr :rest, :global

  def input(assigns) do
    ~H"""
    <div class="space-y-1">
      <%= if @label do %>
        <label for={@name} class="block text-sm font-medium text-gray-700">
          <%= @label %>
          <%= if @required do %>
            <span class="text-red-500">*</span>
          <% end %>
        </label>
      <% end %>
      <input
        type={@type}
        name={@name}
        id={@name}
        value={@value}
        required={@required}
        class={[
          "block w-full rounded-md border-gray-300 shadow-sm",
          "focus:border-blue-500 focus:ring-blue-500",
          "border px-3 py-2 text-sm"
        ]}
        {@rest}
      />
      <%= if @errors != [] do %>
        <div class="mt-1 text-sm text-red-600">
          <%= for error <- @errors do %>
            <p><%= error %></p>
          <% end %>
        </div>
      <% end %>
    </div>
    """
  end

  @doc "Renders event status badge"
  attr :status, :atom, required: true

  def event_status_badge(%{status: :draft} = assigns) do
    ~H"""
    <.badge text="Rascunho" variant={:default} />
    """
  end

  def event_status_badge(%{status: :published} = assigns) do
    ~H"""
    <.badge text="Publicado" variant={:info} />
    """
  end

  def event_status_badge(%{status: :ongoing} = assigns) do
    ~H"""
    <.badge text="Em andamento" variant={:success} />
    """
  end

  def event_status_badge(%{status: :completed} = assigns) do
    ~H"""
    <.badge text="Concluído" variant={:default} />
    """
  end

  def event_status_badge(%{status: :cancelled} = assigns) do
    ~H"""
    <.badge text="Cancelado" variant={:danger} />
    """
  end

  @doc "Renders role badge"
  attr :role, :atom, required: true

  def role_badge(%{role: :admin} = assigns) do
    ~H"""
    <.badge text="Administrador" variant={:danger} />
    """
  end

  def role_badge(%{role: :speaker} = assigns) do
    ~H"""
    <.badge text="Palestrante" variant={:info} />
    """
  end

  def role_badge(%{role: :student} = assigns) do
    ~H"""
    <.badge text="Estudante" variant={:default} />
    """
  end

  @doc "Format date and time"
  attr :datetime, :any, required: true
  attr :format, :atom, values: [:short, :long, :date_only], default: :short

  def formatted_datetime(assigns) do
    ~H"""
    <time datetime={format_iso(@datetime)}>
      <%= format_datetime(@datetime, @format) %>
    </time>
    """
  end

  defp format_datetime(datetime, :short) do
    Calendar.strftime(datetime, "%d/%m/%Y %H:%M")
  end

  defp format_datetime(datetime, :long) do
    Calendar.strftime(datetime, "%A, %d de %B de %Y às %H:%M")
  end

  defp format_datetime(datetime, :date_only) do
    Calendar.strftime(datetime, "%d/%m/%Y")
  end

  defp format_iso(datetime) do
    Calendar.strftime(datetime, "%Y-%m-%dT%H:%M:%S")
  end

  defp render_icon(:info), do: "ℹ️"
  defp render_icon(:success), do: "✅"
  defp render_icon(:warning), do: "⚠️"
  defp render_icon(:error), do: "❌"
end