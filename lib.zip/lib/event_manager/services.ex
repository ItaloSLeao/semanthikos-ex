defmodule EventManager.Services do
  @moduledoc "Services context consolidating Notifications, Certificates, and Reports logic."
  import Ecto.Query
  alias EventManager.Repo
  alias EventManager.Schemas.{ChatMessage, Certificate, Event, Registration, User}

  ## --- CHAT & NOTIFICATIONS ---

  def create_chat_message(attrs) do
    %ChatMessage{} |> ChatMessage.changeset(attrs) |> Repo.insert() |> broadcast()
  end

  def list_event_chat_messages(event_id, opts \\ []) do
    limit = Keyword.get(opts, :limit, 100)
    from(m in ChatMessage, where: m.event_id == ^event_id, preload: [:user],
         order_by: [asc: m.sent_at], limit: ^limit) |> Repo.all()
  end

  def mark_question_answered(message_id) do
    Repo.get!(ChatMessage, message_id) |> ChatMessage.answer_changeset() |> Repo.update() |> broadcast()
  end

  defp broadcast({:ok, msg}) do
    EventManagerWeb.Endpoint.broadcast("event_chat:#{msg.event_id}", "new_message", %{
      id: msg.id, message: msg.message, user_name: msg.user && msg.user.name,
      sent_at: msg.sent_at, is_question: msg.is_question, is_answered: msg.is_answered
    })
    {:ok, msg}
  end
  defp broadcast(error), do: error

  def broadcast_event_notification(event_id, type, data),
    do: EventManagerWeb.Endpoint.broadcast("event_notifications:#{event_id}", type, data)

  def broadcast_capacity_warning(event_id, remaining_seats),
    do: broadcast_event_notification(event_id, "capacity_warning", %{remaining_seats: remaining_seats})

  def broadcast_event_reminder(event_id, minutes_until),
    do: broadcast_event_notification(event_id, "event_reminder", %{minutes_until: minutes_until})

  ## --- CERTIFICATES ---

  def generate_certificate(user_id, event_id, type \\ :participation) do
    %Certificate{} |> Certificate.changeset(%{user_id: user_id, event_id: event_id, certificate_type: type})
    |> Repo.insert() |> then(&generate_pdf_data/1)
  end

  def generate_event_certificates(event_id) do
    EventManager.Core.list_event_registrations(event_id)
    |> Enum.filter(& &1.attended)
    |> Enum.map(&generate_certificate(&1.user_id, event_id, :participation))
    |> Enum.filter(&match?({:ok, _}, &1)) |> length()
  end

  defp generate_pdf_data({:ok, cert}) do
    user = Repo.get!(User, cert.user_id)
    event = Repo.get!(Event, cert.event_id) |> Repo.preload(:speaker)
    cert |> Ecto.Changeset.change(pdf_data: build_certificate_pdf(user, event, cert)) |> Repo.update()
  end
  defp generate_pdf_data(error), do: error

  def build_certificate_pdf(user, event, cert) do
    """
    <!DOCTYPE html><html><head><meta charset="utf-8"><style>
      body{font-family:Georgia,serif;text-align:center;padding:40px;background:linear-gradient(135deg,#f5f7fa,#c3cfe2)}
      .certificate{border:8px double #2c5282;padding:60px;margin:20px auto;max-width:800px;background:#fff;box-shadow:0 4px 6px rgba(0,0,0,.1)}
      .header{font-size:36px;color:#2c5282;margin-bottom:30px;font-weight:700;text-transform:uppercase}
      .title{font-size:48px;color:#1a365d;margin:20px 0}
      .content{font-size:18px;line-height:1.8;color:#2d3748}
      .recipient{font-size:32px;color:#2c5282;font-weight:700;margin:20px 0;border-bottom:2px solid #e2e8f0;padding-bottom:10px;display:inline-block}
      .event-title{font-size:24px;color:#4a5568;margin:15px 0}
      .details{margin-top:30px;font-size:14px;color:#718096}
      .signature{margin-top:40px;border-top:1px solid #cbd5e0;padding-top:20px}
      .certificate-number{font-size:12px;color:#a0aec0;margin-top:40px}
    </style></head><body><div class="certificate">
      <div class="header">Certificado</div>
      <div class="title">#{cert_type(cert.certificate_type)}</div>
      <div class="content"><p>Certificamos que</p><div class="recipient">#{user.name}</div>
      <p>participou do evento</p><div class="event-title">"#{event.title}"</div>
      <p>realizado em #{fmt_date(event.date)}, com duração de #{event.duration_minutes} minutos,
         na modalidade #{if event.is_online, do: "online", else: "presencial"}.</p><p>#{event.location}</p></div>
      <div class="details"><p>#{if event.speaker, do: "Palestrante: #{event.speaker.name}", else: ""}</p>
      <p>Carga horária: #{div(event.duration_minutes, 60)} hora(s)</p></div>
      <div class="signature"><p>_________________________________</p><p>Coordenação de Eventos Acadêmicos</p>
      <p>Data de emissão: #{fmt_date(cert.generated_at)}</p></div>
      <div class="certificate-number">Número do Certificado: #{cert.certificate_number}</div>
    </div></body></html>
    """
  end

  defp cert_type(:participation), do: "Participação"
  defp cert_type(:speaker), do: "Apresentação"
  defp cert_type(:organizer), do: "Organização"
  defp fmt_date(dt), do: Calendar.strftime(dt, "%d/%m/%Y às %H:%M")

  def get_certificate!(id), do: Repo.get!(Certificate, id)
  def get_certificate_by_number(number), do: Repo.get_by(Certificate, certificate_number: number) |> Repo.preload([:user, :event])

  def list_user_certificates(user_id) do
    from(c in Certificate, where: c.user_id == ^user_id, preload: [:event], order_by: [desc: c.generated_at]) |> Repo.all()
  end

  def list_event_certificates(event_id) do
    from(c in Certificate, where: c.event_id == ^event_id, preload: [:user], order_by: [asc: c.generated_at]) |> Repo.all()
  end

  def verify_certificate(number) do
    case get_certificate_by_number(number) do
      nil -> {:error, :not_found}
      cert -> {:ok, %{certificate_number: cert.certificate_number, user_name: cert.user.name, event_title: cert.event.title,
                      event_date: cert.event.date, generated_at: cert.generated_at, verified: cert.verified}}
    end
  end

  ## --- REPORTS ---

  def get_system_stats do
    %{
      total_events: Repo.aggregate(Event, :count, :id),
      total_users: Repo.aggregate(User, :count, :id),
      total_registrations: Repo.aggregate(Registration, :count, :id),
      upcoming_events: from(e in Event, where: e.date > ^DateTime.utc_now() and e.status == :published) |> Repo.aggregate(:count, :id),
      completed_events: from(e in Event, where: e.status == :completed) |> Repo.aggregate(:count, :id)
    }
  end

  def get_occupancy_report(opts \\ []) do
    from(e in Event, where: e.status in [:published, :completed], order_by: [desc: e.date])
    |> maybe_limit(opts[:limit]) |> Repo.all() |> Repo.preload([:registrations])
    |> Enum.map(fn event ->
      regs = length(event.registrations)
      %{event_id: event.id, title: event.title, date: event.date, max_seats: event.max_seats,
        registrations: regs, occupancy_rate: Float.round(regs / event.max_seats * 100, 2),
        remaining_seats: event.max_seats - regs}
    end)
  end

  def get_participation_by_course(_opts \\ []) do
    from(u in User, left_join: r in Registration, on: r.user_id == u.id, where: not is_nil(u.course),
      group_by: u.course,
      select: %{course: u.course, total_registrations: count(r.id),
                total_attended: fragment("COUNT(CASE WHEN ? THEN 1 END)", r.attended)},
      order_by: [desc: count(r.id)]) |> Repo.all()
  end

  def get_participation_by_department do
    from(u in User, left_join: r in Registration, on: r.user_id == u.id, where: not is_nil(u.department),
      group_by: u.department,
      select: %{department: u.department, total_registrations: count(r.id),
                total_attended: fragment("COUNT(CASE WHEN ? THEN 1 END)", r.attended)},
      order_by: [desc: count(r.id)]) |> Repo.all()
  end

  def get_monthly_stats(year \\ DateTime.utc_now().year) do
    from(e in Event, where: fragment("EXTRACT(YEAR FROM ?) = ?", e.date, ^year),
      group_by: fragment("EXTRACT(MONTH FROM date)"),
      select: %{month: fragment("EXTRACT(MONTH FROM date)"), total_events: count(e.id), total_seats: sum(e.max_seats)},
      order_by: [asc: fragment("EXTRACT(MONTH FROM date)")]) |> Repo.all()
  end

  def export_registrations_csv(event_id) do
    regs = from(r in Registration, where: r.event_id == ^event_id, preload: [:user], order_by: [asc: r.registered_at]) |> Repo.all()
    headers = ["Nome", "Email", "Curso", "Departamento", "Data Registro", "Presença"]
    rows = Enum.map(regs, fn r ->
      [r.user.name, r.user.email, r.user.course || "N/A", r.user.department || "N/A",
       Calendar.strftime(r.registered_at, "%d/%m/%Y %H:%M"), if(r.attended, do: "Sim", else: "Não")]
    end)
    [headers | rows] |> CSV.encode() |> Enum.to_list() |> IO.iodata_to_binary()
  end

  def export_events_csv(opts \\ []) do
    events = EventManager.Core.list_events(opts)
    headers = ["Título", "Data", "Local", "Vagas", "Inscritos", "Ocupação (%)", "Status"]
    rows = Enum.map(events, fn e ->
      regs = length(e.registrations || [])
      [e.title, Calendar.strftime(e.date, "%d/%m/%Y %H:%M"), e.location, e.max_seats, regs,
       Float.round(regs / max(e.max_seats, 1) * 100, 2), Atom.to_string(e.status)]
    end)
    [headers | rows] |> CSV.encode() |> Enum.to_list() |> IO.iodata_to_binary()
  end

  def get_speaker_stats(speaker_id) do
    events = from(e in Event, where: e.speaker_id == ^speaker_id, preload: [:registrations]) |> Repo.all()
    total_events = length(events)
    total_regs = events |> Enum.map(&length(&1.registrations)) |> Enum.sum()
    %{speaker_id: speaker_id, total_events: total_events, total_registrations: total_regs,
      average_registrations: if(total_events > 0, do: total_regs / total_events, else: 0)}
  end

  defp maybe_limit(query, nil), do: query
  defp maybe_limit(query, limit), do: limit(query, ^limit)
end