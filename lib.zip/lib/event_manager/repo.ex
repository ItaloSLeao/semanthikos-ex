defmodule EventManager.Repo do
  @moduledoc """
  Ecto repository module for database operations.
  Uses PostgreSQL as the data store.
  """
  use Ecto.Repo,
    otp_app: :event_manager,
    adapter: Ecto.Adapters.Postgres

  import Ecto.Query

  @doc """
  Execute a transaction with optimistic locking for seat reservation.
  Prevents overbooking by checking seat availability atomically.
  """
  def reserve_seat(event_id, user_id) do
    Ecto.Multi.new()
    |> Ecto.Multi.run(:event, fn repo, _ ->
      case repo.get(EventManager.Schemas.Event, event_id) do
        nil -> {:error, :event_not_found}
        event -> {:ok, event}
      end
    end)
    |> Ecto.Multi.run(:check_seats, fn repo, %{event: event} ->
      current_registrations =
        from(r in EventManager.Schemas.Registration,
          where: r.event_id == ^event_id,
          select: count(r.id)
        )
        |> repo.one()

      if current_registrations < event.max_seats do
        {:ok, :seats_available}
      else
        {:error, :no_seats_available}
      end
    end)
    |> Ecto.Multi.insert(:registration, fn %{event: _event} ->
      %EventManager.Schemas.Registration{}
      |> Ecto.Changeset.change(event_id: event_id, user_id: user_id)
      |> Ecto.Changeset.unique_constraint([:user_id, :event_id], name: :registrations_user_event_index)
    end)
    |> transaction()
  end

  @doc """
  Full-text search for events using PostgreSQL tsvector.
  Searches across title and description fields.
  """
  def search_events(query_term) do
    from e in EventManager.Schemas.Event,
      where: fragment("to_tsvector('portuguese', title || ' ' || description) @@ plainto_tsquery('portuguese', ?)", ^query_term),
      order_by: [desc: e.date],
      select: e
  end
end
